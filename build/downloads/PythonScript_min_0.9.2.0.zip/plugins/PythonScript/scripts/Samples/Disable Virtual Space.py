
# Disable the virtual space options for both Scintilla views, apart from for rectangular selection (the default in Notepad++)
# For more information, see the Scintilla documentation on virtual space and the SCI_SETVIRTUALSPACEOPTIONS message.

editor1.setVirtualSpaceOptions(1)
editor2.setVirtualSpaceOptions(1)
